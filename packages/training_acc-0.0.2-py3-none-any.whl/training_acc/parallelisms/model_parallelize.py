from ..dist.initialize import is_initialized
from .parallelize_mochi import parallelize_mochi
from .parallelize_llama2 import parallelize_llama2
from .parallelize_hunyuan import parallelize_hunyuan
from .parallelize_flux_pipeline import parallelize_flux_pipeline
from .parallelize_wanx2_1_t2v import parallelize_wanx2_1_t2v

model_parallelize_fns = {
    "mochi": parallelize_mochi,
    "llama2": parallelize_llama2,
    "hunyuan": parallelize_hunyuan,
    "flux_pipeline": parallelize_flux_pipeline,
    "wanx2_1_t2v": parallelize_wanx2_1_t2v,
}


def get_supported_models():
    return list(model_parallelize_fns.keys())


def parallelize(name, model):
    if not is_initialized():
        raise RuntimeError(
            f"It has not been initialized yet. Please call the initialize function first.")

    if name not in model_parallelize_fns:
        raise RuntimeError(
            f"Only {list(model_parallelize_fns.keys())} is supported. Got unsupported model name: {name}")

    return model_parallelize_fns[name](model)
