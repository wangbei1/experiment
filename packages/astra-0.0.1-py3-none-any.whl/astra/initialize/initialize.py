from ..config import EngineConfig, ParallelConfig
from ..parallel import parallel_initialize

INITIALIZED = False


def _get_configs(num_gpus, sp_parallel_size):
    engine_config = EngineConfig(num_gpus=num_gpus)
    parallel_config = ParallelConfig(sp_degree=sp_parallel_size)
    return engine_config, parallel_config


def initialize(sp_parallel_size=1):
    engine_config, parallel_config = _get_configs(None, sp_parallel_size)

    parallel_initialize(parallel_config=parallel_config)

    global INITIALIZED
    INITIALIZED = True


def is_initialized():
    return INITIALIZED
