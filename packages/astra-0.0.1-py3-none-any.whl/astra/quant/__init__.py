# quantize_oneshot
