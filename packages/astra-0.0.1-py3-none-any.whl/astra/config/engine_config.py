from dataclasses import dataclass, fields


@dataclass
class EngineConfig:
    num_gpus: int = 1
