from ..config import EngineConfig, ParallelConfig
from ..initialize import is_initialized
from .map_fns import model_accelerate_fns, pipeline_accelerate_fns


class ModelType:
    model: str = "model"
    pipeline: str = "pipeline"


def get_supported_models():
    return list(model_accelerate_fns.keys())


def get_supported_pipelines():
    return list(pipeline_accelerate_fns.keys())


def accelerate(name, model_or_pipe_instance, model_type=ModelType.model):
    if not is_initialized():
        raise RuntimeError(
            f"It has not been initialized yet. Please call the initialize function first.")

    if model_type == ModelType.model:
        accelerate_fns = model_accelerate_fns
    else:
        accelerate_fns = pipeline_accelerate_fns

    if name not in accelerate_fns:
        raise RuntimeError(
            f"Only {list(accelerate_fns.keys())} is supported. Got unsupported name: {name}")

    return accelerate_fns[name](model_or_pipe_instance)
