from .accelerate_wanx2_1_t2v import accelerate_wanx2_1_t2v
from .accelerate_wanx2_1_i2v import accelerate_wanx2_1_i2v

__all__ = ["accelerate_wanx2_1_t2v", "accelerate_wanx2_1_i2v"]
