from ...parallel import parallelize


def _apply_parallel(model):
    model = parallelize("wanx2_1_t2v", model)
    return model


def accelerate_wanx2_1_t2v(model):
    _apply_parallel(model)
    return model
