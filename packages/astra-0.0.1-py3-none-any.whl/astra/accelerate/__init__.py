from .accelerate import accelerate

__all__ = ["accelerate"]