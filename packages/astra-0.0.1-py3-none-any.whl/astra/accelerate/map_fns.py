from .models import accelerate_wanx2_1_t2v, accelerate_wanx2_1_i2v

model_accelerate_fns = {
    "wanx2_1_t2v": accelerate_wanx2_1_t2v,
    "wanx2_1_i2v": accelerate_wanx2_1_i2v
}

pipeline_accelerate_fns = {
}
