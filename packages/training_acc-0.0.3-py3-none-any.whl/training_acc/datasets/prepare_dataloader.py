import torch
from torch.utils.data import Dataset, DataLoader
from torch.utils.data.distributed import DistributedSampler


class PrepareDataloader:
    def __init__(self,
                 # dataloader
                 dataset,
                 batch_size,
                 pin_memory=False,
                 num_workers=0,
                 # sampler
                 num_replicas=None,
                 rank=None,
                 shuffle: bool = True,
                 seed: int = 0,
                 drop_last: bool = False,
                 **kwargs):
        self.sampler = DistributedSampler(
            dataset,
            num_replicas=num_replicas,
            rank=rank,
            shuffle=shuffle,
            seed=seed,
            drop_last=drop_last
        )
        self.dataloader = DataLoader(
            dataset,
            batch_size=batch_size,
            sampler=self.sampler,
            pin_memory=pin_memory,
            num_workers=num_workers,
            **kwargs,
        )

    def get_dataloader(self):
        return self.dataloader

    def set_sampler_epoch(self, epoch):
        self.sampler.set_epoch(epoch)
