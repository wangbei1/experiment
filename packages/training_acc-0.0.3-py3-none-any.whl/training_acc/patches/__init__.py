from .apply_ulysses_attn_monkey_patch_flux_transformer import apply_ulysses_attn_monkey_patch_flux_transformer, prepare_flux_inputs, prepare_flux_outputs, apply_new_flux_attn_monkey_patch_flux_transformer, prepare_flux_latents_input, prepare_flux_imgids_input
from .apply_ulysses_attn_monkey_patch_flux_transformer import prepare_flux_padding_inputs, prepare_flux_padding_outputs
from .apply_ulysses_attn_monkey_patch_transformer import apply_ulysses_attn_monkey_patch_transformer
from .apply_ulysses_attn_monkey_patch_llama2 import apply_ulysses_attn_monkey_patch_llama2, prepare_llama2_inputs, prepare_llama2_outputs, prepare_llama2_padding_inputs, prepare_llama2_padding_outputs

# for astra module api
import os
import importlib
curr_dir = os.path.abspath(os.path.dirname(__file__))
entries = os.listdir(curr_dir)
for entry in entries:
    path = os.path.join(curr_dir, entry)
    if os.path.isdir(path):
        if entry == "__pycache__":
            continue
        importlib.import_module(f"training_acc.patches.{entry}")
