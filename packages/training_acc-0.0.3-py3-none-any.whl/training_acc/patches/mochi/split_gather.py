from ...dist import parallel_state
from ...comm.split_gather import split_forward_gather_backward, gather_forward_split_backward


def split_x(x, dim):
    return split_forward_gather_backward(parallel_state.get_sequence_parallel_group(), x, dim=dim)


def gather_x(x, dim):
    return gather_forward_split_backward(parallel_state.get_sequence_parallel_group(), x, dim=dim)
