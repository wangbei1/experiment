import torch
import torch.distributed as dist
from einops import rearrange

from ...dist import parallel_state
from ...comm.all_to_all import _SeqAllToAll4D, _SeqAllToAll5D


def collect_tokens(x):
    group = parallel_state.get_sequence_parallel_group()
    # (bs, seqlen/P, 3, hc, hd) -> (bs, seq_len, 3, hc/P, hd)
    return _SeqAllToAll5D.apply(group, x, 3, 1)


def collect_heads(x):
    group = parallel_state.get_sequence_parallel_group()
    # (bs, seqlen, hc/P, hd) -> (bs, seqlen/P, hc, hd)
    return _SeqAllToAll4D.apply(group, x, 1, 2)
