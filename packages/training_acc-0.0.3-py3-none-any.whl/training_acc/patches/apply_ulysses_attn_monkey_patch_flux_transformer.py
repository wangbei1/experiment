import torch
from typing import Callable, List, Optional, Tuple, Union
from diffusers.models.attention_processor import Attention
import torch.nn.functional as F
from dataclasses import dataclass, fields
from deepspeed.sequence.layer import DistributedAttention
import deepspeed
from functools import partial
import math

from ..comm.split_gather import _split, _gather, split_forward_gather_backward, gather_forward_split_backward
from ..dist import parallel_state


def apply_rope(xq, xk, freqs_cis):
    # YiYi to-do: refactor rope related functions/classes
    xq_ = xq.float().reshape(*xq.shape[:-1], -1, 1, 2)
    xk_ = xk.float().reshape(*xk.shape[:-1], -1, 1, 2)
    xq_out = freqs_cis[..., 0] * xq_[..., 0] + freqs_cis[..., 1] * xq_[..., 1]
    xk_out = freqs_cis[..., 0] * xk_[..., 0] + freqs_cis[..., 1] * xk_[..., 1]
    return xq_out.reshape(*xq.shape).type_as(xq), xk_out.reshape(*xk.shape).type_as(xk)


def torch_attn(query,
               key,
               value,
               dropout_p,
               causal,
               ):
    # the output of sdp = (batch, num_heads, seq_len, head_dim)
    return F.scaled_dot_product_attention(
        query, key, value, dropout_p=dropout_p, is_causal=causal
    )


# ------------------------------------------------------------------------------------------- #
# sdpa -> dist attn
@dataclass
class AttnProcessType:
    ulysses: str = "ulysses"
    sdpa: str = "sdpa"


def pad_inputs(inputs, dim):
    sequence_parallel_group = parallel_state.get_sequence_parallel_group()
    sequence_parallel_size = parallel_state.get_sequence_parallel_size()
    sequence_parallel_rank = parallel_state.get_sequence_parallel_rank()

    batch, num_heads, seq_len, head_dim = inputs.shape
    seq_pad_size = math.ceil(seq_len/sequence_parallel_size) * \
        sequence_parallel_size - seq_len
    pad = torch.zeros(batch, num_heads, seq_pad_size,
                      head_dim, dtype=inputs.dtype, device=inputs.device)
    inputs = torch.cat((inputs, pad), dim=2)
    return inputs, seq_len


class _UlyssesAttnSplitForwardGatherBackward(torch.autograd.Function):
    @staticmethod
    def forward(ctx, inputs):
        inputs, seq_len = pad_inputs(inputs, 2)
        ctx.seq_len = seq_len
        return _split(inputs, 2, parallel_state.get_sequence_parallel_group()), seq_len

    @staticmethod
    def backward(ctx, *grad_output):
        grad_output = _gather(
            grad_output[0], 2, parallel_state.get_sequence_parallel_group())
        return grad_output[:, :, :ctx.seq_len, :]


class _UlyssesAttnGatherForwardSplitBackward(torch.autograd.Function):
    @staticmethod
    def forward(ctx, inputs, seq_len):
        inputs = _gather(
            inputs, 2, parallel_state.get_sequence_parallel_group())
        return inputs[:, :, :seq_len, :]

    @staticmethod
    def backward(ctx, grad_output):
        grad_output, _ = pad_inputs(grad_output, 2)
        return _split(grad_output, 2, parallel_state.get_sequence_parallel_group()), None


def ulysses_attn_split_forward_gather_backward(inputs):
    return _UlyssesAttnSplitForwardGatherBackward.apply(inputs)


def ulysses_attn_gather_forward_split_backward(inputs, seq_len):
    return _UlyssesAttnGatherForwardSplitBackward.apply(inputs, seq_len)


class DistFluxAttnProcessor2_0:
    """Attention processor used typically in processing the SD3-like self-attention projections."""

    def __init__(self, attn_process_type=AttnProcessType.sdpa, sp_group=None):
        if attn_process_type == AttnProcessType.sdpa:
            if not hasattr(F, "scaled_dot_product_attention"):
                raise ImportError(
                    "FluxAttnProcessor2_0 requires PyTorch 2.0, to use it, please upgrade PyTorch to 2.0.")
            self.sdpa_attn = partial(
                F.scaled_dot_product_attention, dropout_p=0.0, is_causal=False)
        elif attn_process_type == AttnProcessType.ulysses:
            self.ulysses_attn = DistributedAttention(
                partial(torch_attn, dropout_p=0.0, causal=False), sp_group, scatter_idx=1, gather_idx=2)
        self.attn_process_type = attn_process_type

    def __call__(
        self,
        attn: Attention,
        hidden_states: torch.FloatTensor,
        encoder_hidden_states: torch.FloatTensor = None,
        attention_mask: Optional[torch.FloatTensor] = None,
        image_rotary_emb: Optional[torch.Tensor] = None,
    ) -> torch.FloatTensor:
        input_ndim = hidden_states.ndim
        if input_ndim == 4:
            batch_size, channel, height, width = hidden_states.shape
            hidden_states = hidden_states.view(
                batch_size, channel, height * width).transpose(1, 2)
        context_input_ndim = encoder_hidden_states.ndim
        if context_input_ndim == 4:
            batch_size, channel, height, width = encoder_hidden_states.shape
            encoder_hidden_states = encoder_hidden_states.view(
                batch_size, channel, height * width).transpose(1, 2)

        batch_size = encoder_hidden_states.shape[0]

        # `sample` projections.
        query = attn.to_q(hidden_states)
        key = attn.to_k(hidden_states)
        value = attn.to_v(hidden_states)

        inner_dim = key.shape[-1]
        head_dim = inner_dim // attn.heads

        query = query.view(batch_size, -1, attn.heads,
                           head_dim).transpose(1, 2)
        key = key.view(batch_size, -1, attn.heads, head_dim).transpose(1, 2)
        value = value.view(batch_size, -1, attn.heads,
                           head_dim).transpose(1, 2)

        if attn.norm_q is not None:
            query = attn.norm_q(query)
        if attn.norm_k is not None:
            key = attn.norm_k(key)

        # `context` projections.
        encoder_hidden_states_query_proj = attn.add_q_proj(
            encoder_hidden_states)
        encoder_hidden_states_key_proj = attn.add_k_proj(encoder_hidden_states)
        encoder_hidden_states_value_proj = attn.add_v_proj(
            encoder_hidden_states)

        encoder_hidden_states_query_proj = encoder_hidden_states_query_proj.view(
            batch_size, -1, attn.heads, head_dim
        ).transpose(1, 2)
        encoder_hidden_states_key_proj = encoder_hidden_states_key_proj.view(
            batch_size, -1, attn.heads, head_dim
        ).transpose(1, 2)
        encoder_hidden_states_value_proj = encoder_hidden_states_value_proj.view(
            batch_size, -1, attn.heads, head_dim
        ).transpose(1, 2)

        if attn.norm_added_q is not None:
            encoder_hidden_states_query_proj = attn.norm_added_q(
                encoder_hidden_states_query_proj)
        if attn.norm_added_k is not None:
            encoder_hidden_states_key_proj = attn.norm_added_k(
                encoder_hidden_states_key_proj)

        # attention => seq len 4096+77
        query = torch.cat([encoder_hidden_states_query_proj, query], dim=2)
        key = torch.cat([encoder_hidden_states_key_proj, key], dim=2)
        value = torch.cat([encoder_hidden_states_value_proj, value], dim=2)

        if image_rotary_emb is not None:
            # YiYi to-do: update uising apply_rotary_emb
            # from ..embeddings import apply_rotary_emb
            # query = apply_rotary_emb(query, image_rotary_emb)
            # key = apply_rotary_emb(key, image_rotary_emb)
            query, key = apply_rope(query, key, image_rotary_emb)

        if self.attn_process_type == AttnProcessType.sdpa:
            hidden_states = self.sdpa_attn(
                query, key, value)
        elif self.attn_process_type == AttnProcessType.ulysses:
            # b,hc,seqlen,hd
            local_q, q_seq_len = ulysses_attn_split_forward_gather_backward(
                query)
            local_k, k_seq_len = ulysses_attn_split_forward_gather_backward(
                key)
            local_v, v_seq_len = ulysses_attn_split_forward_gather_backward(
                value)
            assert q_seq_len == k_seq_len == v_seq_len

            local_hidden_states = self.ulysses_attn(
                local_q, local_k, local_v, batch_dim_idx=0)

            hidden_states = ulysses_attn_gather_forward_split_backward(
                local_hidden_states, q_seq_len)

        hidden_states = hidden_states.transpose(1, 2).reshape(
            batch_size, -1, attn.heads * head_dim)
        hidden_states = hidden_states.to(query.dtype)

        encoder_hidden_states, hidden_states = (
            hidden_states[:, : encoder_hidden_states.shape[1]],
            hidden_states[:, encoder_hidden_states.shape[1]:],
        )

        # linear proj
        hidden_states = attn.to_out[0](hidden_states)
        # dropout
        hidden_states = attn.to_out[1](hidden_states)
        encoder_hidden_states = attn.to_add_out(encoder_hidden_states)

        if input_ndim == 4:
            hidden_states = hidden_states.transpose(
                -1, -2).reshape(batch_size, channel, height, width)
        if context_input_ndim == 4:
            encoder_hidden_states = encoder_hidden_states.transpose(
                -1, -2).reshape(batch_size, channel, height, width)

        return hidden_states, encoder_hidden_states


def apply_ulysses_attn_monkey_patch_flux_transformer(model):
    for layer_id, transformer_block in enumerate(model.transformer_blocks):
        transformer_block.attn.set_processor(DistFluxAttnProcessor2_0(
            AttnProcessType.ulysses, parallel_state.get_sequence_parallel_group()))

# ------------------------------------------------------------------------------------------- #
# ulysses split inputs by seq


class NewFluxAttnProcessor2_0:
    """Attention processor used typically in processing the SD3-like self-attention projections."""

    def __init__(self):
        self.ulysses_attn = DistributedAttention(
            partial(torch_attn, dropout_p=0.0, causal=False), parallel_state.get_sequence_parallel_group(), scatter_idx=1, gather_idx=2)

    def __call__(
        self,
        attn: Attention,
        hidden_states: torch.FloatTensor,
        encoder_hidden_states: torch.FloatTensor = None,
        attention_mask: Optional[torch.FloatTensor] = None,
        image_rotary_emb: Optional[torch.Tensor] = None,
    ) -> torch.FloatTensor:
        input_ndim = hidden_states.ndim
        if input_ndim == 4:
            batch_size, channel, height, width = hidden_states.shape
            hidden_states = hidden_states.view(
                batch_size, channel, height * width).transpose(1, 2)
        context_input_ndim = encoder_hidden_states.ndim
        if context_input_ndim == 4:
            batch_size, channel, height, width = encoder_hidden_states.shape
            encoder_hidden_states = encoder_hidden_states.view(
                batch_size, channel, height * width).transpose(1, 2)

        batch_size = encoder_hidden_states.shape[0]

        # `sample` projections.
        query = attn.to_q(hidden_states)
        key = attn.to_k(hidden_states)
        value = attn.to_v(hidden_states)

        inner_dim = key.shape[-1]
        head_dim = inner_dim // attn.heads

        query = query.view(batch_size, -1, attn.heads,
                           head_dim).transpose(1, 2)
        key = key.view(batch_size, -1, attn.heads, head_dim).transpose(1, 2)
        value = value.view(batch_size, -1, attn.heads,
                           head_dim).transpose(1, 2)

        if attn.norm_q is not None:
            query = attn.norm_q(query)
        if attn.norm_k is not None:
            key = attn.norm_k(key)

        # `context` projections.
        encoder_hidden_states_query_proj = attn.add_q_proj(
            encoder_hidden_states)
        encoder_hidden_states_key_proj = attn.add_k_proj(encoder_hidden_states)
        encoder_hidden_states_value_proj = attn.add_v_proj(
            encoder_hidden_states)

        encoder_hidden_states_query_proj = encoder_hidden_states_query_proj.view(
            batch_size, -1, attn.heads, head_dim
        ).transpose(1, 2)
        encoder_hidden_states_key_proj = encoder_hidden_states_key_proj.view(
            batch_size, -1, attn.heads, head_dim
        ).transpose(1, 2)
        encoder_hidden_states_value_proj = encoder_hidden_states_value_proj.view(
            batch_size, -1, attn.heads, head_dim
        ).transpose(1, 2)

        if attn.norm_added_q is not None:
            encoder_hidden_states_query_proj = attn.norm_added_q(
                encoder_hidden_states_query_proj)
        if attn.norm_added_k is not None:
            encoder_hidden_states_key_proj = attn.norm_added_k(
                encoder_hidden_states_key_proj)

        # attention => seq len 4096+77
        query = torch.cat([encoder_hidden_states_query_proj, query], dim=2)
        key = torch.cat([encoder_hidden_states_key_proj, key], dim=2)
        value = torch.cat([encoder_hidden_states_value_proj, value], dim=2)

        if image_rotary_emb is not None:
            # YiYi to-do: update uising apply_rotary_emb
            # from ..embeddings import apply_rotary_emb
            # query = apply_rotary_emb(query, image_rotary_emb)
            # key = apply_rotary_emb(key, image_rotary_emb)
            query, key = apply_rope(query, key, image_rotary_emb)

        hidden_states = self.ulysses_attn(
            query, key, value, batch_dim_idx=0)

        hidden_states = hidden_states.transpose(1, 2).reshape(
            batch_size, -1, attn.heads * head_dim)
        hidden_states = hidden_states.to(query.dtype)

        encoder_hidden_states, hidden_states = (
            hidden_states[:, : encoder_hidden_states.shape[1]],
            hidden_states[:, encoder_hidden_states.shape[1]:],
        )

        # linear proj
        hidden_states = attn.to_out[0](hidden_states)
        # dropout
        hidden_states = attn.to_out[1](hidden_states)
        encoder_hidden_states = attn.to_add_out(encoder_hidden_states)

        if input_ndim == 4:
            hidden_states = hidden_states.transpose(
                -1, -2).reshape(batch_size, channel, height, width)
        if context_input_ndim == 4:
            encoder_hidden_states = encoder_hidden_states.transpose(
                -1, -2).reshape(batch_size, channel, height, width)

        return hidden_states, encoder_hidden_states


class NewFluxSingleAttnProcessor2_0:
    r"""
    Processor for implementing scaled dot-product attention (enabled by default if you're using PyTorch 2.0).
    """

    def __init__(self):
        self.ulysses_attn = DistributedAttention(
            partial(torch_attn, dropout_p=0.0, causal=False), parallel_state.get_sequence_parallel_group(), scatter_idx=1, gather_idx=2)

    def __call__(
        self,
        attn: Attention,
        hidden_states: torch.Tensor,
        encoder_hidden_states: Optional[torch.Tensor] = None,
        attention_mask: Optional[torch.FloatTensor] = None,
        image_rotary_emb: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        input_ndim = hidden_states.ndim

        if input_ndim == 4:
            batch_size, channel, height, width = hidden_states.shape
            hidden_states = hidden_states.view(
                batch_size, channel, height * width).transpose(1, 2)

        batch_size, _, _ = hidden_states.shape if encoder_hidden_states is None else encoder_hidden_states.shape

        query = attn.to_q(hidden_states)
        if encoder_hidden_states is None:
            encoder_hidden_states = hidden_states

        key = attn.to_k(encoder_hidden_states)
        value = attn.to_v(encoder_hidden_states)

        inner_dim = key.shape[-1]
        head_dim = inner_dim // attn.heads

        query = query.view(batch_size, -1, attn.heads,
                           head_dim).transpose(1, 2)

        key = key.view(batch_size, -1, attn.heads, head_dim).transpose(1, 2)
        value = value.view(batch_size, -1, attn.heads,
                           head_dim).transpose(1, 2)

        if attn.norm_q is not None:
            query = attn.norm_q(query)
        if attn.norm_k is not None:
            key = attn.norm_k(key)

        # Apply RoPE if needed
        if image_rotary_emb is not None:
            # YiYi to-do: update uising apply_rotary_emb
            # from ..embeddings import apply_rotary_emb
            # query = apply_rotary_emb(query, image_rotary_emb)
            # key = apply_rotary_emb(key, image_rotary_emb)
            query, key = apply_rope(query, key, image_rotary_emb)

        hidden_states = self.ulysses_attn(
            query, key, value, batch_dim_idx=0)

        hidden_states = hidden_states.transpose(1, 2).reshape(
            batch_size, -1, attn.heads * head_dim)
        hidden_states = hidden_states.to(query.dtype)

        if input_ndim == 4:
            hidden_states = hidden_states.transpose(
                -1, -2).reshape(batch_size, channel, height, width)

        return hidden_states


def prepare_flux_inputs(
    latents, img_ids
):
    # b,s,h
    local_latents = split_forward_gather_backward(
        parallel_state.get_sequence_parallel_group(), latents, dim=1)
    local_img_ids = split_forward_gather_backward(
        parallel_state.get_sequence_parallel_group(), img_ids, dim=1)
    return local_latents, local_img_ids


def prepare_flux_latents_input(
    latents
):
    # b,s,h
    local_latents = split_forward_gather_backward(
        parallel_state.get_sequence_parallel_group(), latents, dim=1)
    return local_latents


def prepare_flux_imgids_input(
    img_ids
):
    # b,s,h
    local_img_ids = split_forward_gather_backward(
        parallel_state.get_sequence_parallel_group(), img_ids, dim=1)
    return local_img_ids


def prepare_flux_outputs(
    outputs
):
    # b,s,h
    return gather_forward_split_backward(
        parallel_state.get_sequence_parallel_group(), outputs, dim=1)


def apply_new_flux_attn_monkey_patch_flux_transformer(model):
    for layer_id, transformer_block in enumerate(model.transformer_blocks):
        transformer_block.attn.set_processor(NewFluxAttnProcessor2_0())
    for layer_id, single_transformer_block in enumerate(model.single_transformer_blocks):
        single_transformer_block.attn.set_processor(
            NewFluxSingleAttnProcessor2_0())


def padding_tokens(tokens):
    # -----vidgen token padding-----
    sequence_parallel_group = parallel_state.get_sequence_parallel_group()
    sequence_parallel_size = parallel_state.get_sequence_parallel_size()
    sequence_parallel_rank = parallel_state.get_sequence_parallel_rank()

    b, s, h = tokens.shape
    token_pad_size = math.ceil(s/sequence_parallel_size) * \
        sequence_parallel_size - s
    pad = torch.zeros(b, token_pad_size, h,
                      dtype=tokens.dtype, device=tokens.device)
    tokens = torch.cat((tokens, pad), dim=1)

    return tokens


class InputsSplitForwardGatherBackward(torch.autograd.Function):
    # b,s,h
    @staticmethod
    def forward(ctx, inputs):
        _, seqlen, _ = inputs.shape
        inputs = padding_tokens(inputs)
        ctx.seqlen = seqlen
        return _split(inputs, 1, parallel_state.get_sequence_parallel_group())

    @staticmethod
    def backward(ctx, grad_output):
        grad_output = _gather(
            grad_output, 1, parallel_state.get_sequence_parallel_group())
        return grad_output[:, :ctx.seqlen, :]


class OutputsGatherForwardSplitBackward(torch.autograd.Function):
    @staticmethod
    def forward(ctx, inputs, seqlen):
        inputs = _gather(
            inputs, 1, parallel_state.get_sequence_parallel_group())
        return inputs[:, :seqlen, :]

    @staticmethod
    def backward(ctx, grad_output):
        grad_output = padding_tokens(grad_output)
        return _split(grad_output, 1, parallel_state.get_sequence_parallel_group()), None


def prepare_flux_padding_inputs(inputs):
    return InputsSplitForwardGatherBackward.apply(inputs)


def prepare_flux_padding_outputs(inputs, seqlen):
    return OutputsGatherForwardSplitBackward.apply(inputs, seqlen)
