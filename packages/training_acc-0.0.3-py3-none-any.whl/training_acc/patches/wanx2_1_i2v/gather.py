from ...dist import parallel_state
from ...comm.split_gather import gather_forward_split_backward

def gather(x, dim):
    return gather_forward_split_backward(parallel_state.get_sequence_parallel_group(), x, dim=dim)
