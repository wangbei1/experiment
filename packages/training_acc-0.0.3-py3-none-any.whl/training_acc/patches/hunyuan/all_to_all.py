import torch
from einops import rearrange

from ...dist import parallel_state
from ...comm.all_to_all import _SeqAllToAll4D, _SeqAllToAll5D


def collect_tokens(x):
    group = parallel_state.get_sequence_parallel_group()
    # (bs, s/N, hc, hd) -> (bs, s, hc/N, hd)
    return _SeqAllToAll4D.apply(group, x, 2, 1)


def collect_heads(x, heads_num):
    group = parallel_state.get_sequence_parallel_group()
    cp_size = parallel_state.get_sequence_parallel_size()

    assert heads_num % cp_size == 0, f"heads_num is not divisible by cp_size. heads_num:{heads_num}, cp_size:{cp_size}"
    heads_num = heads_num // cp_size

    x = rearrange(x, "B S (HN HD) -> B S HN HD", HN=heads_num).contiguous()
    # (bs, s, hc/N, hd) -> (bs, s/N, hc, hd)
    x = _SeqAllToAll4D.apply(group, x, 1, 2)
    x = rearrange(x, "B S HN HD -> B S (HN HD)").contiguous()
    return x
