import torch
import math
from functools import partial
import torch.nn.functional as F
from deepspeed.sequence.layer import DistributedAttention

from ..comm.split_gather import _split, _gather, split_forward_gather_backward, gather_forward_split_backward
from ..dist import parallel_state
from ..models import llama2
from ..models.llama2 import apply_rotary_emb, repeat_kv


def attn_forward(
    self,
    x: torch.Tensor,
    freqs_cis: torch.Tensor,
):
    """
    Forward pass of the attention module.

    Args:
        x (torch.Tensor): Input tensor.
        freqs_cis (torch.Tensor): Precomputed frequency tensor.

    Returns:
        torch.Tensor: Output tensor after attention.

    """
    bsz, seqlen, _ = x.shape
    xq, xk, xv = self.wq(x), self.wk(x), self.wv(x)

    xq = xq.view(bsz, seqlen, self.n_heads, self.head_dim)
    xk = xk.view(bsz, seqlen, self.n_kv_heads, self.head_dim)
    xv = xv.view(bsz, seqlen, self.n_kv_heads, self.head_dim)

    xq, xk = apply_rotary_emb(xq, xk, freqs_cis=freqs_cis)

    keys = repeat_kv(xk, self.n_rep)  # (bs, seqlen, n_local_heads, head_dim)
    values = repeat_kv(xv, self.n_rep)  # (bs, seqlen, n_local_heads, head_dim)

    xq = xq.transpose(1, 2)  # (bs, n_local_heads, seqlen, head_dim)
    xk = keys.transpose(1, 2)  # (bs, n_local_heads, seqlen, head_dim)
    xv = values.transpose(1, 2)  # (bs, n_local_heads, seqlen, head_dim)

    # we use casual mask for training
    output = F.scaled_dot_product_attention(xq, xk, xv, is_causal=True)
    output = output.transpose(
        1, 2
    ).contiguous()  # (bs, seqlen, n_local_heads, head_dim)
    output = output.view(bsz, seqlen, -1)
    return self.wo(output)


def new_attn_split_kqv_forward(
    self,
    x: torch.Tensor,
    freqs_cis: torch.Tensor,
):
    """
    Forward pass of the attention module.

    Args:
        x (torch.Tensor): Input tensor.
        freqs_cis (torch.Tensor): Precomputed frequency tensor.

    Returns:
        torch.Tensor: Output tensor after attention.

    """
    bsz, seqlen, _ = x.shape
    xq, xk, xv = self.wq(x), self.wk(x), self.wv(x)

    xq = xq.view(bsz, seqlen, self.n_heads, self.head_dim)
    xk = xk.view(bsz, seqlen, self.n_kv_heads, self.head_dim)
    xv = xv.view(bsz, seqlen, self.n_kv_heads, self.head_dim)

    xq, xk = apply_rotary_emb(xq, xk, freqs_cis=freqs_cis)

    keys = repeat_kv(xk, self.n_rep)  # (bs, seqlen, n_local_heads, head_dim)
    values = repeat_kv(xv, self.n_rep)  # (bs, seqlen, n_local_heads, head_dim)

    xq = xq.transpose(1, 2)  # (bs, n_local_heads, seqlen, head_dim)
    xk = keys.transpose(1, 2)  # (bs, n_local_heads, seqlen, head_dim)
    xv = values.transpose(1, 2)  # (bs, n_local_heads, seqlen, head_dim)

    # we use casual mask for training
    # output = F.scaled_dot_product_attention(xq, xk, xv, is_causal=True)

    # b,hc,seqlen,hd => 8,16,256,16
    xq = split_forward_gather_backward(
        parallel_state.get_sequence_parallel_group(), xq, 2)
    xk = split_forward_gather_backward(
        parallel_state.get_sequence_parallel_group(), xk, 2)
    xv = split_forward_gather_backward(
        parallel_state.get_sequence_parallel_group(), xv, 2)

    sdpa_attn = partial(F.scaled_dot_product_attention, is_causal=True)
    ulysses_attn = DistributedAttention(
        sdpa_attn, parallel_state.get_sequence_parallel_group(), scatter_idx=1, gather_idx=2)
    output = ulysses_attn(
        xq, xk, xv, batch_dim_idx=0)
    output = gather_forward_split_backward(
        parallel_state.get_sequence_parallel_group(), output, 2)

    output = output.transpose(
        1, 2
    ).contiguous()  # (bs, seqlen, n_local_heads, head_dim)
    output = output.view(bsz, seqlen, -1)
    return self.wo(output)


def new_attn_forward(
    self,
    x: torch.Tensor,
    freqs_cis: torch.Tensor,
):
    """
    Forward pass of the attention module.

    Args:
        x (torch.Tensor): Input tensor.
        freqs_cis (torch.Tensor): Precomputed frequency tensor.

    Returns:
        torch.Tensor: Output tensor after attention.

    """
    bsz, seqlen, _ = x.shape
    xq, xk, xv = self.wq(x), self.wk(x), self.wv(x)

    xq = xq.view(bsz, seqlen, self.n_heads, self.head_dim)
    xk = xk.view(bsz, seqlen, self.n_kv_heads, self.head_dim)
    xv = xv.view(bsz, seqlen, self.n_kv_heads, self.head_dim)

    xq, xk = apply_rotary_emb(xq, xk, freqs_cis=freqs_cis)

    keys = repeat_kv(xk, self.n_rep)  # (bs, seqlen, n_local_heads, head_dim)
    values = repeat_kv(xv, self.n_rep)  # (bs, seqlen, n_local_heads, head_dim)

    xq = xq.transpose(1, 2)  # (bs, n_local_heads, seqlen, head_dim)
    xk = keys.transpose(1, 2)  # (bs, n_local_heads, seqlen, head_dim)
    xv = values.transpose(1, 2)  # (bs, n_local_heads, seqlen, head_dim)

    sdpa_attn = partial(F.scaled_dot_product_attention, is_causal=True)
    ulysses_attn = DistributedAttention(
        sdpa_attn, parallel_state.get_sequence_parallel_group(), scatter_idx=1, gather_idx=2)
    output = ulysses_attn(
        xq, xk, xv, batch_dim_idx=0)

    output = output.transpose(
        1, 2
    ).contiguous()  # (bs, seqlen, n_local_heads, head_dim)
    output = output.view(bsz, seqlen, -1)
    return self.wo(output)


def apply_ulysses_attn_monkey_patch_llama2(model):
    llama2.Attention.forward = (
        new_attn_forward
    )


def prepare_llama2_inputs(
    src_ids, tgt_ids
):
    # b,s
    local_src_ids = split_forward_gather_backward(
        parallel_state.get_sequence_parallel_group(), src_ids, dim=1)
    local_tgt_ids = split_forward_gather_backward(
        parallel_state.get_sequence_parallel_group(), tgt_ids, dim=1)
    return local_src_ids, local_tgt_ids


def prepare_llama2_outputs(
    outputs
):
    # b,s,h
    return gather_forward_split_backward(
        parallel_state.get_sequence_parallel_group(), outputs, dim=1)


def padding_inputs(inputs):
    sequence_parallel_group = parallel_state.get_sequence_parallel_group()
    sequence_parallel_size = parallel_state.get_sequence_parallel_size()
    sequence_parallel_rank = parallel_state.get_sequence_parallel_rank()

    b, s = inputs.shape
    token_pad_size = math.ceil(s/sequence_parallel_size) * \
        sequence_parallel_size - s
    pad = torch.zeros(b, token_pad_size,
                      dtype=inputs.dtype, device=inputs.device)
    inputs = torch.cat((inputs, pad), dim=1)

    return inputs


def padding_outputs(outputs):
    sequence_parallel_group = parallel_state.get_sequence_parallel_group()
    sequence_parallel_size = parallel_state.get_sequence_parallel_size()
    sequence_parallel_rank = parallel_state.get_sequence_parallel_rank()

    b, s, h = outputs.shape
    token_pad_size = math.ceil(s/sequence_parallel_size) * \
        sequence_parallel_size - s
    pad = torch.zeros(b, token_pad_size, h,
                      dtype=outputs.dtype, device=outputs.device)
    outputs = torch.cat((outputs, pad), dim=1)

    return outputs


class InputsSplitForwardGatherBackward(torch.autograd.Function):
    @staticmethod
    def forward(ctx, inputs):
        _, seqlen = inputs.shape
        inputs = padding_inputs(inputs)
        ctx.seqlen = seqlen
        return _split(inputs, 1, parallel_state.get_sequence_parallel_group())

    @staticmethod
    def backward(ctx, grad_output):
        print(
            f"InputsSplitForwardGatherBackward backward grad_output shape:{grad_output.shape}")
        grad_output = _gather(
            grad_output, 1, parallel_state.get_sequence_parallel_group())
        return grad_output[:, :ctx.seqlen]


class OutputsGatherForwardSplitBackward(torch.autograd.Function):
    @staticmethod
    def forward(ctx, inputs, seqlen):
        inputs = _gather(
            inputs, 1, parallel_state.get_sequence_parallel_group())
        return inputs[:, :seqlen, :]

    @staticmethod
    def backward(ctx, grad_output):
        grad_output = padding_outputs(grad_output)
        return _split(grad_output, 1, parallel_state.get_sequence_parallel_group()), None


def prepare_llama2_padding_inputs(inputs):
    return InputsSplitForwardGatherBackward.apply(inputs)


def prepare_llama2_padding_outputs(inputs, seqlen):
    return OutputsGatherForwardSplitBackward.apply(inputs, seqlen)
