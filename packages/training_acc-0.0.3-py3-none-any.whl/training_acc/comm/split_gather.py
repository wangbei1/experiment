import torch
import torch.distributed as dist


def _gather(inputs, dim=-1, group=None):
    world_size = dist.get_world_size(group)
    if world_size == 1:
        return inputs

    # all gather
    inputs = inputs.contiguous()
    tensor_list = [torch.empty_like(inputs) for _ in range(world_size)]
    dist.all_gather(tensor_list, inputs, group=group)

    output = torch.cat(tensor_list, dim=dim).contiguous()

    return output


def _split(inputs, dim=-1, group=None):
    world_size = dist.get_world_size(group)
    if world_size == 1:
        return inputs

    # Split along dimension.
    dim_size = inputs.size(dim)
    assert dim_size % world_size == 0, (
        f"The dimension to split ({dim_size}) is not a multiple of world size ({world_size}), "
        f"cannot split tensor evenly"
    )

    tensor_list = torch.split(inputs, dim_size // world_size, dim=dim)
    rank = dist.get_rank(group)
    output = tensor_list[rank].contiguous()

    return output


class _SplitForwardGatherBackward(torch.autograd.Function):
    """Split the input.

    Args:
        inputs: input matrix.
        dim: dimension
        group: process group
    """

    @staticmethod
    def forward(ctx, inputs, dim, group):
        ctx.group = group
        ctx.dim = dim
        return _split(inputs, dim, group)

    @staticmethod
    def backward(ctx, grad_output):
        return _gather(grad_output, ctx.dim, ctx.group), None, None


class _GatherForwardSplitBackward(torch.autograd.Function):
    """Gather the input from model parallel region and concatenate.

    Args:
        inputs: input matrix.
        dim: dimension
        group: process group
    """

    @staticmethod
    def forward(ctx, inputs, dim, group):
        ctx.group = group
        ctx.dim = dim
        return _gather(inputs, dim, group)

    @staticmethod
    def backward(ctx, grad_output):
        return _split(grad_output, ctx.dim, ctx.group), None, None


def split_forward_gather_backward(group, inputs, dim):
    return _SplitForwardGatherBackward.apply(inputs, dim, group)


def gather_forward_split_backward(group, inputs, dim):
    return _GatherForwardSplitBackward.apply(inputs, dim, group)
