from ..config.parallel_config import ParallelConfig
from ..dist import runtime_state, is_main_process
from ..logger import logger

'''
Transformer
x --
    |-> cat ->  patch_embedding -> cat seq_len-x -> [x] split seq --
y --
t -> time_embedding -> time_projection-e0                           | -> blocks:ModuleList[AttentionBlock] -> head -> [x] gather seq -> unpatchify
context -> cat text_len -> text_embedding --                       
                                            | -> cat-context      --
clip_fea -> img_emb                       --
seq_len


AttentionBlock
x -> self_attn:SelfAttention --
                               | -> cross_attn:CrossAttention -> norm2 -> ffn
context                      --

SelfAttention
      -- q -> norm -> [q] alltoall_ct -> rope_apply --
x -> |-- k -> norm -> [k] alltoall_ct -> rope_apply   | -> flash_attention -> [x] alltoall_ch -> flatten -> o
      -- v         -> [v] alltoall_ct --
      
CrossAttention
x -> q               -> norm_q                         -> [q] alltoall_ct --
                                        -- k -> norm_k -> [k] split hc    --| -> flash_attention -> [x] alltoall_ch -> flatten             --
                     -- context     -> |                                    |                                                                |   
context -> split -> |                   -- v              [v] split hc    --                                                                 | -> add -> o
                    |                                                                                                                        |
                    |                   -- k_img -> norm_k_img -> [k] split hc    --| -> flash_attention -> [img_x] alltoall_ch -> flatten --                                   
                     -- context_img -> |                                            |
                                        -- v_img                  [v] split hc    --
'''


def apply_sp(model, parallel_config):
    if is_main_process():
        logger.info(f"Applied sp {parallel_config.sp_degree} to the model")

    return model


def parallelize_wanx2_1_i2v(model):
    parallel_config: ParallelConfig = runtime_state.get_parallel_config()
    if parallel_config.sp_degree > 1:
        model = apply_sp(model, parallel_config)

    return model
