from ..config.parallel_config import ParallelConfig
from ..dist import runtime_state, is_main_process
from ..logger import logger

'''
FluxTransformer2DModel
hidden_states -> x_embedder:Linear              --                                             - hidden_states         --
encoder_hidden_states -> context_embedder:Linear  | -> transformer_blocks:FluxTransformerBlock|                          |-> cat|hidden_states -- 
                                                  |                                            - encoder_hidden_states --                        |
timestep -> time_text_embed|temb                --                                                                                                -- -> single_transformer_blocks:FluxSingleTransformerBlock -> norm_out:AdaLayerNormContinuous -> proj_out:Linear|output
img_ids-                                          |                                                                                              |
        |-> cat|ids -> pos_embed|image_rotary_emb-                                                                                             --                                                                     
txt_ids-

FluxTransformerBlock
hidden_states -> norm1:AdaLayerNormZero                 --  -> attn|hidden_states -> norm2:LayerNorm -> ff:FeedForward|hidden_states
encoder_hidden_states -> norm1_context:AdaLayerNormZero   |                       -> norm2_context:LayerNorm -> ff_context:FeedForward|encoder_hidden_states
temb                                                      |                       
image_rotary_emb                                        --

FluxSingleTransformerBlock
hidden_states -> norm:AdaLayerNormZeroSingle --  -> proj_mlp -> act_mlp|mlp_hidden_states --
                                               |                                            | -> cat|hidden_states -> proj_out:Linear
temb                                           | -> attn|attn_output                      -- 
image_rotary_emb                             --
'''

''' sp parallel
FluxTransformer2DModel
hidden_states -> x_embedder:Linear              --                                             - hidden_states         --
encoder_hidden_states -> context_embedder:Linear  | -> transformer_blocks:FluxTransformerBlock|                          |-> cat|hidden_states -- 
                                                  |                                            - encoder_hidden_states --                        |
timestep -> time_text_embed|temb                --                                                                                                -- -> single_transformer_blocks:FluxSingleTransformerBlock -> norm_out:AdaLayerNormContinuous -> proj_out:Linear|output
img_ids-                                          |                                                                                              |
        |-> cat|ids -> pos_embed|image_rotary_emb-                                                                                             --                                                                     
txt_ids-

FluxTransformerBlock
hidden_states -> norm1:AdaLayerNormZero                 --  -> attn|hidden_states -> norm2:LayerNorm -> ff:FeedForward|hidden_states
encoder_hidden_states -> norm1_context:AdaLayerNormZero   |                       -> norm2_context:LayerNorm -> ff_context:FeedForward|encoder_hidden_states
temb                                                      |                       
image_rotary_emb                                        --

FluxSingleTransformerBlock
hidden_states -> norm:AdaLayerNormZeroSingle --  -> proj_mlp -> act_mlp|mlp_hidden_states --
                                               |                                            | -> cat|hidden_states -> proj_out:Linear
temb                                           | -> attn|attn_output                      -- 
image_rotary_emb                             --
'''


def apply_sp(model, parallel_config):
    if is_main_process():
        logger.info(f"Applied sp {parallel_config.sp_degree} to the model")

    return model


def parallelize_flux_pipeline(pipe: "diffusers.FluxPipeline"):
    parallel_config: ParallelConfig = runtime_state.get_parallel_config()
    if parallel_config.sp_degree > 1:
        model = apply_sp(model, parallel_config)

    return model
