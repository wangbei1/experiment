from ..config.activation_checkpoint_config import ActivationCheckpointConfig, ACMode
from ..config.parallel_config import ParallelConfig
from ..dist import runtime_state, is_main_process
from ..activation_checkpoint import selective_ac
from ..logger import logger


def apply_ac(model, ac_config):
    for layer_id, transformer_block in model.blocks.named_children():
        transformer_block = selective_ac(transformer_block, ac_config)
        model.blocks.register_module(layer_id, transformer_block)

    if is_main_process():
        logger.info(
            f"Applied {ac_config.ac_mode} activation checkpointing to the model")
    return model


def apply_sp(model, parallel_config):
    if is_main_process():
        logger.info(f"Applied sp {parallel_config.sp_degree} to the model")
    return model


def parallelize_mochi(model):
    parallel_config: ParallelConfig = runtime_state.get_parallel_config()
    if parallel_config.sp_degree > 1:
        model = apply_sp(model, parallel_config)

    ac_config: ActivationCheckpointConfig = runtime_state.get_activation_checkpoint_config()
    if ac_config.ac_mode != ACMode.no:
        model = apply_ac(model, ac_config)
    return model
