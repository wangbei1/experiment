from ..config.parallel_config import ParallelConfig
from ..dist import runtime_state, is_main_process
from ..logger import logger

'''
Transformer
x -> patch_embedding -> cat seq_len -> [x] split seq  --
t -> time_embedding -> time_projection                  | -> blocks:ModuleList[AttentionBlock] -> head -> [x] gather seq -> unpatchify
context -> cat text_len -> text_embedding             --
seq_len

AttentionBlock
x -> self_attn:SelfAttention --
                               | -> cross_attn:CrossAttention -> norm2 -> ffn
context                      --

SelfAttention
      -- q -> norm -> [q] alltoall_ct -> rope_apply --
x -> |-- k -> norm -> [k] alltoall_ct -> rope_apply   | -> flash_attention -> [x] alltoall_ch -> flatten -> o
      -- v         -> [v] alltoall_ct --
      
CrossAttention
x -> q -> norm_q           -> [q] alltoall_ct --
            -- k -> norm_k -> [k] split hc    --| -> flash_attention -> [x] alltoall_ch -> flatten -> o
context -> |                                    |
            -- v              [v] split hc    --
'''


def apply_sp(model, parallel_config):
    if is_main_process():
        logger.info(f"Applied sp {parallel_config.sp_degree} to the model")

    return model


def parallelize_wanx2_1_t2v(model):
    parallel_config: ParallelConfig = runtime_state.get_parallel_config()
    if parallel_config.sp_degree > 1:
        model = apply_sp(model, parallel_config)

    return model
