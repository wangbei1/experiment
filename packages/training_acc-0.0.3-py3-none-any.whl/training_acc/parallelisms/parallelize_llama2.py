from ..config.activation_checkpoint_config import ActivationCheckpointConfig, ACMode
from ..dist import runtime_state, is_main_process
from ..activation_checkpoint import selective_ac
from ..logger import logger


def apply_ac(model, ac_config):
    for layer_id, transformer_block in model.layers.named_children():
        transformer_block = selective_ac(transformer_block, ac_config)
        model.layers.register_module(layer_id, transformer_block)

    if is_main_process():
        logger.info(
            f"Applied {ac_config.ac_mode} activation checkpointing to the model")
    return model


def parallelize_llama2(model):
    ac_config: ActivationCheckpointConfig = runtime_state.get_activation_checkpoint_config()
    logger.info(f"ac_mode:{ac_config.ac_mode}, ac_freq:{ac_config.ac_freq}")
    if ac_config.ac_mode != ACMode.no:
        model = apply_ac(model, ac_config)
    return model
