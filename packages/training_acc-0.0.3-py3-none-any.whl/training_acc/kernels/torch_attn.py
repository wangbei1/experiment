import torch.nn.functional as F


def torch_attn(query,
               key,
               value,
               dropout_p=0.0,
               causal=False,
               ):
    batch_size, seq_len, hs, hd = query.size()
    query = query.view(batch_size, -1, hs, hd).transpose(1, 2)
    key = key.view(batch_size, -1, hs, hd).transpose(1, 2)
    value = value.view(batch_size, -1, hs, hd).transpose(1, 2)

    # the output of sdp = (batch, num_heads, seq_len, head_dim)
    # TODO: add support for attn.scale when we move to Torch 2.1
    hidden_states = F.scaled_dot_product_attention(
        query, key, value, dropout_p=dropout_p, is_causal=causal
    )

    hidden_states = hidden_states.transpose(1, 2).reshape(
        batch_size, -1, hs, hd
    )
    hidden_states = hidden_states.to(query.dtype)
    return hidden_states
