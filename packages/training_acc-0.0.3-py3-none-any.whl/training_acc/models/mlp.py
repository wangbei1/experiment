from typing import Any, Optional, Union

import torch
import torch.distributed as dist
import torch.nn as nn


class MLP(nn.Module):
    """
    Basic MLP (multi-layer perceptron) layer. Dropout is neglected.
    """

    def __init__(
        self,
        d_model: int,
        device: Optional[Union[str, torch.device]] = None,
        dtype: Optional[torch.dtype] = None,
    ) -> None:
        super().__init__()

        self.in_proj = nn.Linear(d_model, 4 * d_model,
                                 device=device, dtype=dtype)
        self.act_fn = nn.GELU()
        self.out_proj = nn.Linear(
            4 * d_model, d_model, device=device, dtype=dtype)

    def forward(self, inputs: torch.Tensor) -> torch.Tensor:
        x = self.in_proj(inputs)
        x = self.act_fn(x)
        x = self.out_proj(x)
        return x
