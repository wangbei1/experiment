'''
AsymmDiTJoint
img token:x -> [x]split seq                --
txt token:y                                  | -> AsymmetricJointBlock -> FinalLayer -> [x]gather seq
timestamp:c                                  |
rope:rope_cos&rope_sin -> [rope]split head --

AsymmetricJointBlock
x ---------
y          | -> AsymmetricAttention -> RMSNorm -> ff_block
c -> silu -

AsymmetricAttention
x -> linear -> [x]all_to_all              --
                                            | -> cat qkv -> attn -> [x]all_to_all -> proj_x -> [y] gather -> proj_y
y -> RMSNorm -> [y proj weight]split head --
'''
