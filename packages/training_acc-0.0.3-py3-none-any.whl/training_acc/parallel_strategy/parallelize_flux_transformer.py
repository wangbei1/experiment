import torch
import deepspeed

from ..config import ParallelConfig
from ..dist import parallel_state
from ..patches import apply_new_flux_attn_monkey_patch_flux_transformer

# FluxTransformer2DModel

# FluxTransformerBlock
'''
norm1         
                => attn => norm2 => ff => norm2_context => ff_context
norm1_context
'''
# FluxSingleTransformerBlock
'''
norm => linear proj_mlp => gelu act_mlp => attn => linear proj_out
'''
# FeedForward
'''
act_fn => dropout => proj linear
'''
# Attention
'''
to_q    norm_q
to_k => norm_k => sdpa => linear proj => dropout
to_v
'''


def parallelize_flux_transformer(model: torch.nn.Module, parallel_config: ParallelConfig):
    parallel_state.initialize_parallel_state(parallel_config)
    if parallel_config.sp_degree > 1:
        deepspeed.init_distributed()
        apply_new_flux_attn_monkey_patch_flux_transformer(model)

    return model
