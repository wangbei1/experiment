import torch
import deepspeed
from ..config import ParallelConfig
from ..dist import parallel_state
from ..patches import apply_ulysses_attn_monkey_patch_llama2

# TransformerBlock
'''
attention_norm:RMSNorm => attention => ffn_norm:RMSNorm => feed_forward
'''

# Transformer
'''
tok_embeddings => transformer block layers => norm => linear output
'''


def parallelize_llama2(model: torch.nn.Module, parallel_config: ParallelConfig):
    parallel_state.initialize_parallel_state(parallel_config)
    if parallel_config.sp_degree >= 1:
        deepspeed.init_distributed()
        apply_ulysses_attn_monkey_patch_llama2(model)

    return model
