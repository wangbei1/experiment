import time
import torch
from contextlib import nullcontext
from ..logger import logger


class RuntimeMonitor:
    def __init__(self, name, cuda_sync=True, logging=True):
        self.name = name
        self.cuda_sync = cuda_sync
        self.logging = logging

    def __enter__(self):
        if self.cuda_sync:
            torch.cuda.synchronize()
        self.start_value = time.perf_counter()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.cuda_sync:
            torch.cuda.synchronize()
        self.end_value = time.perf_counter()
        if self.logging:
            logger.info(
                f"[{self.name}] Finished executing in { self.elapsed_time} seconds")

    @property
    def elapsed_time(self):
        return self.end_value - self.start_value


def runtime_monitor_ctx(name, cuda_sync=True, logging=True, monitor=True):
    return RuntimeMonitor(name, cuda_sync, logging) if monitor else nullcontext()
