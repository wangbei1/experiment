from ..logger import logger


def diff_results(actual, expected, rank=0, logging="diff_results"):
    diff = actual - expected
    logger.info(f"[{logging} rank {rank}] max {diff.abs().max().item()}, "
                f"mean {diff.abs().mean().item()}",)
