from dataclasses import dataclass, fields


@dataclass
class LauncherConfig:
    ...
