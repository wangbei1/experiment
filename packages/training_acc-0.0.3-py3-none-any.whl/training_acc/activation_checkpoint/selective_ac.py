from ..config.activation_checkpoint_config import ACMode
from .policy import no_ac, full_ac, op_sac, layer_sac_interval, layer_sac_percentage

selective_ac_fns = {
    ACMode.no: no_ac,
    ACMode.full: full_ac,
    ACMode.selective_op: op_sac,
    ACMode.selective_layer_interval: layer_sac_interval,
    ACMode.selective_layer_percentage: layer_sac_percentage,
}


def selective_ac(model, ac_config):
    ac_mode = ac_config.ac_mode
    ac_freq = ac_config.ac_freq
    if ac_mode not in selective_ac_fns:
        raise RuntimeError(
            f"Only {list(selective_ac_fns.keys())} is supported. Got unsupported ac_mode: {ac_mode}")

    if ac_mode in [ACMode.selective_layer_interval, ACMode.selective_layer_percentage]:
        return selective_ac_fns[ac_mode](model, ac_freq)
    else:
        return selective_ac_fns[ac_mode](model)
