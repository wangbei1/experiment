import torch
import deepspeed

from ..config import ParallelConfig
from ..dist import parallel_state
from ..patches import apply_ulysses_attn_monkey_patch_transformer


def parallelize_transformer(model: torch.nn.Module, parallel_config: ParallelConfig):
    parallel_state.initialize_parallel_state(parallel_config)
    if parallel_config.sp_degree > 1:
        deepspeed.init_distributed()
        apply_ulysses_attn_monkey_patch_transformer(model)

    return model
