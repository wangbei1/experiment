import torch
from torch.distributed.tensor.parallel import (
    ColwiseParallel,
    RowwiseParallel,
    parallelize_module,
)

from ..config import ParallelConfig
from ..dist.parallel_state import initialize_parallel_state, get_tensor_parallel_mesh
from ..logger import logger


def parallelize_mlp(model: torch.nn.Module, parallel_config: ParallelConfig):
    initialize_parallel_state(parallel_config)
    if parallel_config.tp_degree > 1:
        tp_mesh = get_tensor_parallel_mesh()

        logger.info(f"tp_mesh:{tp_mesh}")

        plan = {
            "in_proj": ColwiseParallel(),
            "out_proj": RowwiseParallel()
        }

        parallelize_module(model, tp_mesh, plan)

    return model
