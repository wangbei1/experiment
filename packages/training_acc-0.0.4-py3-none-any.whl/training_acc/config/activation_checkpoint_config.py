from dataclasses import dataclass, fields


class ACMode:
    no: str = "no"
    full: str = "full"
    selective_op: str = "selective_op"
    selective_layer_interval: str = "selective_layer_interval"
    selective_layer_percentage: str = "selective_layer_percentage"


@dataclass
class ActivationCheckpointConfig:
    ac_mode: str = ACMode.no
    ac_freq: int = 1
