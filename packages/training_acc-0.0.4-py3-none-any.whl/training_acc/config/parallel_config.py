from dataclasses import dataclass, fields


@dataclass
class ParallelConfig:
    dp_degree: int = -1
    sp_degree: int = 1
    pp_degree: int = 1
    tp_degree: int = 1
