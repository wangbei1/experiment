import torch
from functools import partial
from deepspeed.sequence.layer import DistributedAttention

from ..comm.split_gather import split_forward_gather_backward, gather_forward_split_backward
from ..dist import parallel_state
from ..models import transformer

sdpa_attn = transformer.scaled_dot_product_attention


def new_ulysses_sdpa_attn(Q, K, V, mask=None, ulysses_attn=None):
    local_q = split_forward_gather_backward(
        parallel_state.get_sequence_parallel_group(), Q, 2)
    local_k = split_forward_gather_backward(
        parallel_state.get_sequence_parallel_group(), K, 2)
    local_v = split_forward_gather_backward(
        parallel_state.get_sequence_parallel_group(), V, 2)
    local_mask = split_forward_gather_backward(
        parallel_state.get_sequence_parallel_group(), mask, 2)
    local_output = ulysses_attn(
        Q, K, V, batch_dim_idx=0)
    attn_output = gather_forward_split_backward(
        parallel_state.get_sequence_parallel_group(), local_output, 2)
    return attn_output


def apply_ulysses_attn_monkey_patch_transformer(model):
    ulysses_attn = DistributedAttention(
        sdpa_attn, parallel_state.get_sequence_parallel_group(), scatter_idx=1, gather_idx=2)
    for layer_id, layer in enumerate(model.encoder_layers):
        layer.self_attn.set_processor(
            partial(new_ulysses_sdpa_attn, ulysses_attn=ulysses_attn))
