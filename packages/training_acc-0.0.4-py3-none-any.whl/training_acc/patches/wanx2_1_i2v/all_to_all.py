import torch
from einops import rearrange

from ...dist import parallel_state
from ...comm.all_to_all import _SeqAllToAll4D, _SeqAllToAll5D


@torch.compiler.disable
def collect_tokens(x):
    group = parallel_state.get_sequence_parallel_group()
    # (bs, s/N, hc, hd) -> (bs, s, hc/N, hd)
    return _SeqAllToAll4D.apply(group, x, 2, 1)


@torch.compiler.disable
def collect_heads(x):
    group = parallel_state.get_sequence_parallel_group()
    # (bs, s, hc/N, hd) -> (bs, s/N, hc, hd)
    return _SeqAllToAll4D.apply(group, x, 1, 2)
