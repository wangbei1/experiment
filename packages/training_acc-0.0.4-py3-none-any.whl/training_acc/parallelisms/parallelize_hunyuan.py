from ..config.activation_checkpoint_config import ActivationCheckpointConfig, ACMode
from ..config.parallel_config import ParallelConfig
from ..dist import runtime_state, is_main_process
from ..activation_checkpoint import selective_ac
from ..logger import logger

''' V1
HYVideoDiffusionTransformer
img token: x -> [x] split seq                --
txt token: txt                                 | -> MMDoubleStreamBlock -> MMSingleStreamBlock -> finallayer -> [x] gather seq
timestep: vec                                  |
rope freqs_cos&freqs_sin -> [rope]split head   --



MMDoubleStreamBlock
img -> layernorm -> modulate -> linear -> [img_qkv]all_to_all  -> qknorm -> rope --                         -> [img_attn]all_to_all -> img_attn_proj -> gate -> layernorm -> modulate -> img_mlp -> gate2
                                                                                   | -> cat qkv -> attn -> | 
txt -> layernorm -> modulate -> linear -> [txt_qkv]split head  -> qknorm         --                         -> [txt_attn] gather -> txt_attn_proj -> gate -> layernorm -> modulate -> txt_mlp -> gate2

     -> img_mod
vec | 
     -> txt_mod
 


MMSingleStreamBlock
MMSingleStreamBlock的输入是将img和txt的token concat在一起了, 与flux一样, 可能会涉及先split img和txt, 然后只对img做all_to_all

                                                    -> [img_qkv]all_to_all -> qknorm -> rope --                                   -> [img_attn]all_to_all    --      
x  -> layernorm -> modulate -> linear -> split qkv |                                            | -> cat qkv -> attn -> split -> |                             | -> cat -> linear2 -> gate
                                                    -> [txt_qkv]split head -> qknorm        --                                    -> [txt_attn]gather       -- 
vec -> modulation
'''


''' V2
HYVideoDiffusionTransformer
img token: x                                 --
txt token: txt                                 | -> MMDoubleStreamBlock -> MMSingleStreamBlock -> finallayer
timestep: vec                                  |
rope freqs_cos&freqs_sin                     --



MMDoubleStreamBlock
img -> [img] split seq -> layernorm -> modulate -> linear -> qknorm -> [img_qkv] all_to_all-ct -> rope --                           -- img_attn -> [img_attn] all_to_all-ch -> linear -> gate -> layernorm -> modulate -> mlp -> gate -> img
                                                                                                         | -> cat qkv -> attn -> |
txt -> layernorm -> modulate -> linear -> qknorm -> [txt_qkv] split head                               --                           -- txt_attn -> [txt_attn] gather head -> linear -> gate -> layernorm -> modulate -> mlp -> gate -> txt
 


MMSingleStreamBlock
                                                                         -- img_qkv -> [img_qkv] all_to_all-ct -> rope --                          -- img_attn -> [img_attn] all_to_all-ch -> [img_attn] gather seq --
img --                                              -- qkv -> qknorm -> |                                                | -> cat qkv -> attn  -> |                                                                   | -> cat attn  --
      | -> x -> layernorm -> modulate -> linear -> |                     -- txt_qkv -> [txt_qkv] split head            --                          -- txt_attn -> [txt_attn] gather head                            --                 | -> linear -> gate
txt --                                              -- mlp               --------------------------------------------------------------------------------------------------------------------------------------------------------------
'''

''' V3
HYVideoDiffusionTransformer
img token: img -> [img] split seq            --
txt token: txt                                 | -> MMDoubleStreamBlock -> MMSingleStreamBlock -> finallayer -> [img] gather seq
timestep: vec                                  |
rope freqs_cos&freqs_sin -> [rope] split seq --



MMDoubleStreamBlock
img -> layernorm -> modulate -> linear -> qknorm -> rope -> [img_qkv] all_to_all-ct --                         -- img_attn -> [img_attn] all_to_all-ch -> linear -> gate -> layernorm -> modulate -> mlp -> gate -> img
                                                                                      | -> cat qkv -> attn -> |
txt -> layernorm -> modulate -> linear -> qknorm -> [txt_qkv] split head            --                         -- txt_attn -> [txt_attn] gather head -> linear -> gate -> layernorm -> modulate -> mlp -> gate -> txt
 


MMSingleStreamBlock
                                                                         -- img_qkv -> rope -> [img_qkv] all_to_all-ct --                          -- img_attn -> [img_attn] all_to_all-ch --
img --                                              -- qkv -> qknorm -> |                                                | -> cat qkv -> attn  -> |                                          | -> cat attn --
      | -> x -> layernorm -> modulate -> linear -> |                     -- txt_qkv -> [txt_qkv] split head            --                          -- txt_attn -> [txt_attn] gather head   --                | -> linear -> gate -> x
txt --                                              -- mlp               ------------------------------------------------------------------------------------------------------------------------------------
'''


def apply_sp(model, parallel_config):
    if is_main_process():
        logger.info(f"Applied sp {parallel_config.sp_degree} to the model")
    return model


def parallelize_hunyuan(model):
    parallel_config: ParallelConfig = runtime_state.get_parallel_config()
    if parallel_config.sp_degree > 1:
        model = apply_sp(model, parallel_config)

    return model
