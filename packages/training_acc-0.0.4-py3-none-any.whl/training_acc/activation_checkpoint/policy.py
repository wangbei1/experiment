import torch
from collections import defaultdict
from torch.distributed.algorithms._checkpoint.checkpoint_wrapper import (
    checkpoint_wrapper as ptd_checkpoint_wrapper,
)
from torch.utils.checkpoint import (
    CheckpointPolicy,
    create_selective_checkpoint_contexts,
)

# for selective op activation checkpointing
_save_list = {
    torch.ops.aten.mm.default,
    torch.ops.aten._scaled_dot_product_efficient_attention.default,
    torch.ops.aten._scaled_dot_product_flash_attention.default,
}


def no_ac(module):
    return module


def full_ac(module):
    return ptd_checkpoint_wrapper(module, preserve_rng_state=False)


def op_sac(module):
    def _get_custom_policy(meta):
        def _custom_policy(ctx, func, *args, **kwargs):
            mode = "recompute" if ctx.is_recompute else "forward"
            mm_count_key = f"{mode}_mm_count"
            if func == torch.ops.aten.mm.default:
                meta[mm_count_key] += 1

            # Saves output of all compute ops, except every second mm
            to_save = func in _save_list and not (
                func == torch.ops.aten.mm.default and meta[mm_count_key] % 2 == 0
            )
            return (
                CheckpointPolicy.MUST_SAVE
                if to_save
                else CheckpointPolicy.PREFER_RECOMPUTE
            )

        return _custom_policy

    def selective_checkpointing_context_fn():
        meta = defaultdict(int)
        return create_selective_checkpoint_contexts(_get_custom_policy(meta))

    return ptd_checkpoint_wrapper(
        module,
        context_fn=selective_checkpointing_context_fn,
        preserve_rng_state=False,
    )


def layer_sac_percentage(module, ac_freq):
    ac_freq = eval(ac_freq) if isinstance(ac_freq, str) else ac_freq

    assert ac_freq >= 0 and ac_freq <= 1, "layer_sac_percentage only support 0 <= ac_freq <= 1"

    # Selectivity is defined as a percentage p, which means apply ac on p of the total blocks.
    # p is a floating number in the range of [0, 1].
    ptd_checkpoint_wrapper.__dict__.setdefault("_count", 0)
    ptd_checkpoint_wrapper._count += 1

    ptd_checkpoint_wrapper.__dict__.setdefault("_cut_off", 1/2)
    if ptd_checkpoint_wrapper._count * ac_freq >= ptd_checkpoint_wrapper._cut_off:
        ptd_checkpoint_wrapper._cut_off += 1

        return ptd_checkpoint_wrapper(module, preserve_rng_state=False)
    else:
        return module


def layer_sac_interval(module, ac_freq):
    ac_freq = eval(ac_freq) if isinstance(ac_freq, str) else ac_freq

    assert ac_freq >= 0, "layer_sac_interval only support ac_freq >= 0"

    # Checkpoint every `ac_freq` of the modules passed to this function, ac_freq >= 1
    ptd_checkpoint_wrapper.__dict__.setdefault("_count", 0)
    ptd_checkpoint_wrapper._count += 1
    if not ac_freq or ptd_checkpoint_wrapper._count % ac_freq == 0:
        return ptd_checkpoint_wrapper(module, preserve_rng_state=False)
    else:
        return module
