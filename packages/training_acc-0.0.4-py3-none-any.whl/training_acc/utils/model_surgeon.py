import torch


def get_model_numel(model: torch.nn.Module):
    num_params = 0
    num_params_trainable = 0
    for p in model.parameters():
        num_params += p.numel()
        if p.requires_grad:
            num_params_trainable += p.numel()
    return num_params/1e9, num_params_trainable/1e9


def viz_model(model, input_data, outfile, device='cuda'):
    # install torchview
    from torchview import draw_graph
    
    # device='meta' -> no memory is consumed for visualization
    model_graph = draw_graph(model, input_data=input_data,
                             expand_nested=True, roll=False)
    model_graph.visual_graph.render(
        outfile=outfile, cleanup=True, format="svg")
