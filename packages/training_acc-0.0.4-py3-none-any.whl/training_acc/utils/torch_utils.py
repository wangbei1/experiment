import gc
import os
import torch
import random
import numpy as np
import socket
from functools import partial
from contextlib import nullcontext
from datetime import datetime, timedelta
from torch.autograd.profiler import record_function
from ..logger import logger


def set_seed(seed, deterministic=False):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if deterministic:
        torch.use_deterministic_algorithms(True)


def set_default_dtype(dtype=torch.float32):
    torch.set_default_dtype(dtype)


def set_print_precision(precision=7):
    torch.set_printoptions(precision=precision)


def torch_cuda_mem_inspect(rank=0, empty_cache=True, logging=None):
    if empty_cache:
        n = gc.collect()
        # logger.info("Number of unreachable objects collected by GC:", n)
        torch.cuda.empty_cache()

    dev = torch.device(rank)
    if logging is not None:
        logging = f"[{logging}]"
    else:
        logging = ""
    logger.info(
        f"{logging}[rank {rank}] CUDA memory allocated: {torch.cuda.memory_allocated(dev) / 1e9: .02f} GB, reserved: {torch.cuda.memory_reserved(dev) / 1e9: .02f} GB, max: {torch.cuda.max_memory_allocated(dev) / 1e9: .02f} GB"
    )


# torch profile
TIME_FORMAT_STR: str = "%b_%d_%H_%M_%S"
# Keep a max of 100,000 alloc/free events in the recorded history
# leading up to the snapshot.
MAX_NUM_OF_MEM_EVENTS_PER_SNAPSHOT: int = 100000

# memory snapshot


class TorchMemorySnapshot:
    def __init__(self, monitor=True, rank=0, dir=""):
        self.monitor = monitor

        if not self.monitor:
            return

        self.dir = dir
        self.rank = rank
        os.makedirs(self.dir, exist_ok=True)

    def start(self):
        if not self.monitor:
            return

        if not torch.cuda.is_available():
            logger.info("CUDA unavailable. Not recording memory history")
            return

        logger.info("Starting snapshot record_memory_history")
        torch.cuda.memory._record_memory_history(
            max_entries=MAX_NUM_OF_MEM_EVENTS_PER_SNAPSHOT
        )

    def stop(self):
        if not self.monitor:
            return

        self._export_memory_snapshot(self.dir)
        self._stop_record_memory_history()

    def _stop_record_memory_history(self) -> None:
        if not torch.cuda.is_available():
            logger.info("CUDA unavailable. Not recording memory history")
            return

        logger.info("Stopping snapshot record_memory_history")
        torch.cuda.memory._record_memory_history(enabled=None)

    # https://pytorch.org/memory_viz
    def _export_memory_snapshot(self, dir="") -> None:
        if not torch.cuda.is_available():
            logger.info("CUDA unavailable. Not exporting memory snapshot")
            return

        # Prefix for file names.
        host_name = socket.gethostname()
        timestamp = datetime.now().strftime(TIME_FORMAT_STR)
        file_prefix = os.path.join(
            dir, f"memory_snapshot_rank{self.rank}_{host_name}_{timestamp}")

        try:
            logger.info(f"Saving snapshot to local file: {file_prefix}.pickle")
            torch.cuda.memory._dump_snapshot(f"{file_prefix}.pickle")
        except Exception as e:
            logger.error(f"Failed to capture memory snapshot {e}")
            return

# profiler


class TorchProfiler:
    def __init__(self, wait=1, warmup=1, active=3, repeat=1, monitor=True, rank=0, dir=""):
        self.monitor = monitor

        if not self.monitor:
            return

        self.prof = torch.profiler.profile(
            activities=[
                torch.profiler.ProfilerActivity.CPU,
                torch.profiler.ProfilerActivity.CUDA,
            ],
            schedule=torch.profiler.schedule(
                wait=wait, warmup=warmup, active=active, repeat=repeat),
            record_shapes=True,
            profile_memory=True,
            with_stack=True,
            on_trace_ready=partial(self._trace_handler, dir=dir),
        )
        self.rank = rank

        os.makedirs(dir, exist_ok=True)

    def _trace_handler(self, prof: torch.profiler.profile, dir=""):
        # Prefix for file names.
        host_name = socket.gethostname()
        timestamp = datetime.now().strftime(TIME_FORMAT_STR)
        trace_file_prefix = os.path.join(
            dir, f"profiler_trace_rank{self.rank}_{host_name}_{timestamp}")
        memory_tl_file_prefix = os.path.join(
            dir, f"profiler_memory_timeline_rank{self.rank}_{host_name}_{timestamp}")
        kernel_times_file_prefix = os.path.join(
            dir, f"profiler_kernel_times_rank{self.rank}_{host_name}_{timestamp}")

        # Construct the trace file.
        logger.info(
            f"Saving profiler trace to local file: {trace_file_prefix}.json.gz")
        prof.export_chrome_trace(f"{trace_file_prefix}.json.gz")

        # Construct the memory timeline file.
        logger.info(
            f"Saving profiler memory timeline to local file: {memory_tl_file_prefix}.html")
        prof.export_memory_timeline(
            f"{memory_tl_file_prefix}.html", device=f"cuda:{self.rank}")

        # Construct the kernel times file.
        logger.info(
            f"Saving profiler kernel times to local file: {kernel_times_file_prefix}.txt")
        with open(f"{kernel_times_file_prefix}.txt", "w") as f:
            f.write(prof.key_averages(group_by_stack_n=5).table(
                sort_by="cuda_time_total", row_limit=-1))

    def start(self):
        if not self.monitor:
            return

        logger.info("Starting profiler")
        self.prof.start()

    def step(self):
        if not self.monitor:
            return

        self.prof.step()

    def stop(self):
        if not self.monitor:
            return

        logger.info("Stopping profiler")
        self.prof.stop()

    def record_ctx(self, annotation):
        if not self.monitor:
            return nullcontext()
        else:
            return record_function(annotation)
