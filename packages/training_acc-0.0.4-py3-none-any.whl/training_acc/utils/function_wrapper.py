import time
import torch
import functools
from ..logger import logger


def debugging_method(input_function):
    @functools.wraps(input_function)
    def debugging_wrapper(*args, **kwargs):
        arguments = []
        keyword_arguments = []
        for a in args:
            arguments.append(repr(a))
        for key, value in kwargs.items():
            keyword_arguments.append(f"{key}={value}")
        function_signature = arguments + keyword_arguments
        function_signature = "; ".join(function_signature)
        logger.info(
            f"{input_function.__name__} has the following signature: { function_signature}")
        return_value = input_function(*args, **kwargs)
        logger.info(
            f"{input_function.__name__} has the following return: {return_value}")
        return return_value
    return debugging_wrapper


def runtime_monitor(input_function=None, cuda_sync=True):
    def decorate(input_function):
        @functools.wraps(input_function)
        def runtime_wrapper(*args, **kwargs):
            if cuda_sync:
                torch.cuda.synchronize()
            start_value = time.perf_counter()
            return_value = input_function(*args, **kwargs)
            if cuda_sync:
                torch.cuda.synchronize()
            end_value = time.perf_counter()
            runtime_value = end_value - start_value
            logger.info(
                f"Finished executing {input_function.__name__} in { runtime_value} seconds")
            return return_value
        return runtime_wrapper
    if input_function:
        return decorate(input_function)
    else:
        return decorate
